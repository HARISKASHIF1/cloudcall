import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser'; 
import cookieParser from 'cookie-parser';
import { adminRouter } from './Routes/AdminRoute.js';  // Import your admin routes


const app = express();

// Middleware for parsing JSON body
app.use(express.json());
// Increase the limit for large payloads
// app.use(express.json({ limit: '50mb' })); // Increase the limit as needed

app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
// Middleware for parsing cookies
app.use(cookieParser());

// CORS configuration
app.use(cors({
  origin: ["http://localhost:5174"],  // Frontend URL
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true,  // Allow credentials (cookies) to be sent
}));

// Admin routes
app.use('/api/admin', adminRouter);

// Start server
const PORT = process.env.PORT || 3006; // Use an available port
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
