import mysql from 'mysql';

// const con = mysql.createConnection({
//     host: "192.185.79.28",
//     user: "envision_hr",   
//     password: "o{h!x~hi$_Wn",  
//     database: "envision_hrm"  
// });
const con = mysql.createConnection({
    host: "localhost",
    user: "root",   // Your MySQL username
    password: "",   // Your MySQL password
    database: "employeems"  // Your MySQL database name
});

con.connect(function(err) {
    if (err) {
        console.log("Connection error:", err);
    } else {
        console.log("Connected to MySQL database");
    }
});

export default con;
