import express from "express";
import con from "../utils/db.js";
import jwt from "jsonwebtoken";
import bcrypt from 'bcrypt';
import multer from "multer";
import path from 'path';
import * as XLSX from 'xlsx';
import { fileURLToPath } from 'url'; 
import env from 'dotenv';  // Import dotenv to load environment variables
import nodemailer from 'nodemailer'; // Import nodemailer

// Load environment variables from .env file
// env.config();
const router = express.Router();


// Create a transporter using your SMTP server credentials from the .env file
const transporter = nodemailer.createTransport({
  service: 'gmail',  // Gmail SMTP server
  auth: {
    user: 'thesocialsyncteam@gmail.com',        // Your Gmail email address
    pass: ' tyhuhjdcgvybhdem    ',           // Use the Gmail App Password (not your regular password)
  },
});


// Function to send a welcome email
const sendWelcomeEmail = (employeeEmail, employeeName) => {
  const mailOptions = {
    from: '"Your Company" <your-email@gmail.com>', // Sender address
    to: employeeEmail,  // Employee's email
    subject: 'Welcome to the Company!',  // Email subject
    text: `Hello ${employeeName},\n\nYou have been successfully added to the company.\n\nBest regards,\nYour Company`,  // Plain text body
    html: `<p>Hello ${employeeName},</p><p>You have been successfully added to the company.</p><p>Best regards,<br>Your Company</p>` // HTML body
  };

  // Send the email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error('Error sending email:', error);
    } else {
      console.log('Email sent:', info.response);
    }
  });
};

// Example of sending an email after employee is added
sendWelcomeEmail('recipient@example.com', 'John Doe');








router.post('/adminlogin', (req, res) => {
  const { email, password } = req.body;

  // Check if both email and password are provided
  if (!email || !password) {
      return res.status(400).json({ Status: false, Error: 'Email and password are required' });
  }

  // SQL query to get the user by email
  const sql = "SELECT * FROM admin WHERE email = ?";
  con.query(sql, [email], (err, result) => {
      if (err) {
          console.error('Database error:', err); // Log the error for debugging
          return res.status(500).json({ Status: false, Error: 'Internal server error' });
      }

      if (result.length === 0) {
          return res.status(400).json({ Status: false, Error: 'Invalid email or password' });
      }

      const admin = result[0];

      // Directly compare the provided password with the stored password (without bcrypt)
      if (password !== admin.password) {
          return res.status(400).json({ Status: false, Error: 'Invalid email or password' });
      }

      // If login is successful, send a success response with user data
      return res.status(200).json({
          Status: true,
          LoginStatus: true,
          message: 'Login successful',
          data: {
              id: admin.id,
              name: admin.name,
              email: admin.email
          },
      });
  });
});



// router.post('/add_employee', async (req, res) => {
//   const { name, email, password, address, salary, department_id } = req.body;

//   // Validate that password is a string
//   if (!password || typeof password !== 'string') {
//     return res.status(400).json({ Status: false, Error: "Invalid password" });
//   }

//   const sql = `INSERT INTO employee 
//     (name, email, password, address, salary, department_id) 
//     VALUES (?,?,?,?,?,?)`;

//   try {
//     // Prepare the values for the database query (no hashing)
//     const values = [
//       name,
//       email,
//       password,  // Directly use the password as it is
//       address,
//       salary,
//       department_id
//     ];

//     // Insert the new employee into the database
//     con.query(sql, values, (err, result) => {
//       if (err) {
//         console.error("Database query error:", err);
//         return res.status(500).json({ Status: false, Error: "Database error: " + err.message });
//       }

//       // Send success response
//       return res.status(200).json({ Status: true, Message: "Employee added successfully!" });
//     });

//   } catch (err) {
//     console.error("Error:", err);
//     return res.status(500).json({ Status: false, Error: "Error: " + err.message });
//   }
// });

export default router;


// Backend route for fetching departments
router.get('/department', (req, res) => {
  const sql = "SELECT * FROM department";  // Correct table name
  con.query(sql, (err, result) => {
    if (err) {
      return res.json({ Status: false, Error: "Query Error" });
    }
    return res.json({ Status: true, Result: result });
  });
});


// Backend route for adding department
router.post('/add_department', (req, res) => {
  const { department } = req.body;

  // Validate the input
  if (!department) {
    return res.json({ Status: false, Error: 'Department name is required' });
  }

  const sql = "INSERT INTO department (`name`) VALUES (?)";
  con.query(sql, [department], (err, result) => {
    if (err) {
      return res.json({ Status: false, Error: "Query Error" });
    }
    return res.json({ Status: true });
  });
});






// Employee login route
router.post('/employeelogin', async (req, res) => {
  const { email, password } = req.body;

  // Input validation
  if (!email || !password) {
    return res.status(400).json({ Status: false, Error: 'Email and password are required.' });
  }

  try {
    const sql = 'SELECT id, name, contact_number, password FROM employee WHERE email = ?';
    con.query(sql, [email], (err, results) => {
      if (err) {
        console.error('Database query error:', err);
        return res.status(500).json({ Status: false, Error: 'Internal server error' });
      }

      if (results.length === 0) {
        console.log('Employee not found');
        return res.status(404).json({ Status: false, Error: 'Employee not found.' });
      }

      const employee = results[0];

      // Debugging log to verify password comparison
      console.log('Comparing plain text password:', password);
      console.log('Stored password:', employee.password);

      // Compare plain text password with the one stored in the DB
      if (password !== employee.password) {
        console.log('Password mismatch');
        return res.status(401).json({ Status: false, Error: 'Invalid email or password.' });
      }

      return res.status(200).json({
        Status: true,
        Message: 'Login successful!',
        Employee: {
          id: employee.id,
          name: employee.name,
          email,
          contact_number: employee.contact_number,
        },
      });
    });
  } catch (error) {
    console.error('Error processing login:', error);
    return res.status(500).json({ Status: false, Error: 'Internal server error' });
  }
});





// Backend route to fetch attendance data for employee
// In your backend (e.g., Express server)

router.get('/employeedashboard/:employeeId', async (req, res) => {
  const { employeeId } = req.params;  // Extract employeeId from route parameter

  // Check if the employeeId is provided
  if (!employeeId) {
    return res.status(400).json({ Status: false, Error: 'Employee ID is required' });
  }

  try {
    // Query to fetch attendance data for the employee from the database
    const query = `
      SELECT 
        employee_id, 
        employee_name, 
        date, 
        day, 
        time_in, 
        time_out, 
        hours_worked, 
        delay, 
        status 
      FROM attendance 
      WHERE employee_id = ?
    `;
    
    // Use con.query to query the database
    con.query(query, [employeeId], (error, results) => {
      if (error) {
        console.error('Error fetching attendance:', error);
        return res.status(500).json({ Status: false, Error: 'Error fetching attendance data' });
      }

      // If no attendance records are found, return a 404 response
      if (results.length === 0) {
        return res.status(404).json({ Status: false, Error: 'No attendance records found for this employee' });
      }

      // Send the fetched attendance data as response
      return res.status(200).json({
        Status: true,
        Attendance: results,
      });
    });
    
  } catch (error) {
    // Log error and return a 500 status code if there was an issue querying the database
    console.error('Error fetching attendance:', error);
    return res.status(500).json({ Status: false, Error: 'Error fetching attendance data' });
  }
});





//   const { employeeId } = req.params;  // Extract employeeId from route parameter

//   console.log("Route hit with employeeId:", employeeId);

//   // Validate that the employeeId exists
//   if (!employeeId) {
//     return res.status(400).json({ Status: false, Error: 'Employee ID is required' });
//   }

//   try {
//     // Query the database for attendance records based on employee_id
//     const query = 'SELECT * FROM attendance WHERE employee_id = ?';
//     const attendanceRecords = await queryDatabase(query, [employeeId]);

//     // If no records are found, return a 404 response
//     if (attendanceRecords.length === 0) {
//       return res.status(404).json({ Status: false, Error: 'No attendance records found for this employee' });
//     }

//     // If records are found, return the attendance data
//     return res.status(200).json({
//       Status: true,
//       Attendance: attendanceRecords,
//     });

//   } catch (error) {
//     console.error('Error fetching attendance:', error);
//     return res.status(500).json({ Status: false, Error: 'Error fetching attendance data' });
//   }
// });


// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//       cb(null, 'Public')
//   },
//   filename: (req, file, cb) => {
//       cb(null, file.fieldname + "_" + Date.now() + path.extname(file.originalname))
//   }
// })
// const upload = multer({
//   storage: storage
// })

// router.post('/add_employee', (req, res) => {
//   const sql = `INSERT INTO employee 
//     (name, email, password, address, salary, department_id) 
//     VALUES (?,?,?,?,?,?)`;

//     // bcrypt.hash(password, 10, (err, hashedPassword) => {
//     //   if (err) {
//     //       console.error("Error hashing password:", err);
//     //       return res.status(500).json({ error: "Error hashing password" });
//     //   }
//     const values = [
//       req.body.name,
//       req.body.email,
//       req.body.password,
//       req.body.address,
//       req.body.salary, 
//       req.body.department_id
//     ];

//     con.query(sql, values, (err, result) => {
//       if (err) return res.json({ Status: false, Error: err.message });
//       return res.json({ Status: true, Message: "Employee added successfully!" });
//     });
//   });

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Setup multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Files will be saved in the 'uploads' folder
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    // Generate a unique filename using the current timestamp and file extension
    cb(null, `${Date.now()}${path.extname(file.originalname)}`);
  },
});

const upload1 = multer({ storage });

// Helper function to check for required fields
const checkRequiredFields = (requiredFields, req) => {
  for (let field of requiredFields) {
    if (!req.body[field] || req.body[field].trim() === "") {
      return `The ${field} field is required.`;
    }
  }

  // Check if images are uploaded
  if (!req.files || !req.files.image || !req.files.cnic_image) {
    return "Both employee photo and CNIC image are required.";
  }

  return null;
};


// Helper function to check if images are uploaded
const checkImages = (req) => {
  const imagePath = req.files.image ? req.files.image[0].filename : null;
  const cnicImagePath = req.files.cnic_image ? req.files.cnic_image[0].filename : null;

  if (!imagePath || !cnicImagePath) {
    return 'Both employee photo and CNIC photo are required.';
  }

  return null;
};

// Endpoint to add an employee with photos
router.post('/add_employee', upload1.fields([
  { name: 'image', maxCount: 1 },
  { name: 'cnic_image', maxCount: 1 }
]), async (req, res) => {
  try {
    // Log incoming data
    console.log('Received Body:', req.body);
    console.log('Received Files:', req.files);

    // Validate required fields
    const requiredFields = ['id', 'name', 'email', 'password', 'address', 'salary', 'contact_number'];
    const missingFieldError = checkRequiredFields(requiredFields, req);
    if (missingFieldError) {
      return res.status(400).json({ Status: false, Error: missingFieldError });
    }

    // Check if email already exists in the database
    const { email } = req.body;
    const checkEmployeeEmailQuery = 'SELECT * FROM employee WHERE email = ?';
    con.query(checkEmployeeEmailQuery, [email], async (err, result) => {
      if (err) {
        console.error('Error checking email:', err);
        return res.status(500).json({ Status: false, Error: 'Database query error' });
      }

      if (result.length > 0) {
        return res.status(400).json({ Status: false, Error: 'Employee with this email already exists' });
      }

      // Insert the employee data into the database
      const insertEmployeeQuery = `INSERT INTO employee 
        (id, name, email, password, address, salary, contact_number, image, cnic_image) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

      const image = req.files.image ? req.files.image[0].filename : null;
      const cnicImage = req.files.cnic_image ? req.files.cnic_image[0].filename : null;

      con.query(insertEmployeeQuery, [
        req.body.id, req.body.name, req.body.email, req.body.password,
        req.body.address, req.body.salary, req.body.contact_number, image, cnicImage
      ], (err, result) => {
        if (err) {
          console.error('Error inserting employee:', err);
          return res.status(500).json({ Status: false, Error: 'Error inserting employee' });
        }

        // Send the welcome email after employee is added successfully
        sendWelcomeEmail(req.body.email, req.body.name);

        res.status(200).json({ Status: true, Message: 'Employee added successfully' });
      });
    });
  } catch (err) {
    console.error('Error in add_employee route:', err);
    res.status(500).json({ Status: false, Error: 'Server error' });
  }
});




// Setup static file serving for uploaded images
router.use('/uploads', express.static(path.join(__dirname, 'uploads'), {
  maxAge: '1d', // Cache images for 1 day
}));




  


router.get('/employee', (req, res) => {
  const sql = "SELECT * FROM employee"; // Ensure 'employee' table has 'image' and 'cnic_image' columns
  con.query(sql, (err, result) => {
    if (err) {
      return res.json({ Status: false, Error: "Query Error" });
    }

    // Loop through the result and ensure that the image paths are correct
    const updatedEmployees = result.map(emp => {
      // Ensure the image path is correct (e.g., '/uploads/filename.jpg')
      emp.image = emp.image ? `http://localhost:3006/uploads/${emp.image}` : null;
      emp.cnic_image = emp.cnic_image ? `http://localhost:3006/uploads/${emp.cnic_image}` : null;
      return emp;
    });

    // Return the updated employee data with image paths
    return res.json({ Status: true, Employee: updatedEmployees });
  });
});

  
 // Sample delete API route
 router.delete("/delete_employee/:id", (req, res) => {
  const employeeId = req.params.id;
  console.log("Received DELETE request for employee ID:", employeeId); // Log the received employee ID

  const query = "DELETE FROM employee WHERE id = ?";
  con.query(query, [employeeId], (error, results) => {
    if (error) {
      console.error("Error during DELETE query execution:", error); // Log the error
      return res.status(500).json({ Status: false, Error: "Error deleting employee" });
    }

    if (results.affectedRows === 0) {
      console.log(`No employee found with ID ${employeeId}`); // Log if no rows were deleted
      return res.status(404).json({ Status: false, Error: "Employee not found" });
    }

    console.log(`Employee with ID ${employeeId} deleted successfully`); // Log success
    return res.status(200).json({ Status: true, Message: "Employee deleted successfully" });
  });
});







 // Ensure you have this route to retrieve employee details by ID
 router.get("/employee/:id", (req, res) => {
  const employeeId = req.params.id;
  const query = "SELECT * FROM employee WHERE id = ?";
  con.query(query, [employeeId], (error, results) => {
    if (error) {
      return res.status(500).json({ Status: false, Error: "Error fetching employee data" });
    }
    if (results.length === 0) {
      return res.status(404).json({ Status: false, Error: "Employee not found" });
    }
    res.status(200).json({ Status: true, Result: results });
  });
});


router.put('/edit_employee/:id', (req, res) => {
  const id = req.params.id;
  const { name, email, salary, address, department_name } = req.body;

  // Ensure the data is present before updating
  if (!name || !email || !salary || !address ) {
      return res.status(400).json({ Status: false, Error: "Missing data" });
  }

  // SQL query to update the employee information
  const sql = `UPDATE employee 
      SET name = ?, email = ?, salary = ?, address = ?
      WHERE id = ?`;

  const values = [name, email, salary, address];

  // Execute the query
  con.query(sql, [...values, id], (err, result) => {
      if (err) {
          console.error('Query Error:', err);
          return res.status(500).json({ Status: false, Error: "Query Error: " + err.message });
      }

      // Check if any rows were updated
      if (result.affectedRows === 0) {
          return res.status(404).json({ Status: false, Error: "Employee not found" });
      }

      return res.json({ Status: true, Result: "Employee updated successfully" });
  });
});



// router.get('/dashboard', async (req, res) => {
//   try {
//     // Wrap the queries into Promises to use async/await properly
//     const getTotalEmployees = () => {
//       return new Promise((resolve, reject) => {
//         const employeeSql = "SELECT COUNT(*) AS totalEmployees FROM employee";
//         con.query(employeeSql, (err, result) => {
//           if (err) {
//             reject('Error fetching total employees');
//           } else {
//             resolve(result[0].totalEmployees);  // Resolve with the total employee count
//           }
//         });
//       });
//     };

//     const getDepartments = () => {
//       return new Promise((resolve, reject) => {
//         const departmentSql = `
//           SELECT department.id, department.name, COUNT(employee.id) AS employeeCount
//           FROM department
//           LEFT JOIN employee ON department.id = employee.department_id
//           GROUP BY department.id, department.name
//         `;
//         con.query(departmentSql, (err, result) => {
//           if (err) {
//             reject('Error fetching departments');
//           } else {
//             resolve(result);  // Resolve with the departments data
//           }
//         });
//       });
//     };

//     // Use Promise.all to handle multiple asynchronous tasks
//     const [totalEmployees, departments] = await Promise.all([getTotalEmployees(), getDepartments()]);

//     // Send the response with both total employee count and department details
//     res.json({
//       Status: true,
//       totalEmployees,
//       departments
//     });
    
//   } catch (error) {
//     // Handle errors, including potential promise rejection errors
//     res.status(500).json({
//       Status: false,
//       Error: error.message || 'An error occurred while fetching dashboard data'
//     });
//   }
// });
router.get('/dashboard', async (req, res) => {
  try {
    // Query to get the count of employees
    const getTotalEmployees = () => {
      return new Promise((resolve, reject) => {
        const employeeSql = "SELECT COUNT(*) AS totalEmployees FROM employee";
        con.query(employeeSql, (err, result) => {
          if (err) {
            console.error("Error fetching total employees:", err);
            reject('Error fetching total employees');
          } else {
            resolve(result[0].totalEmployees);
          }
        });
      });
    };

    // Get the total number of employees (no departments)
    const totalEmployees = await getTotalEmployees();

    // Send the response with the total employee count
    res.json({
      Status: true,
      totalEmployees
    });

  } catch (error) {
    console.error("Server error:", error);
    res.status(500).json({
      Status: false,
      Error: error.message || 'An error occurred while fetching dashboard data'
    });
  }
});





  
// Fetch employees route


// Fetch employees route
// router.get('/employee', (req, res) => {
//   const query = 'SELECT id, name FROM employee';  // Query to fetch employee data
//   con.query(query, (err, results) => {
//     if (err) {
//       console.error('Error fetching employee:', err);
//       return res.status(500).json({ message: 'Failed to fetch employee.' });
//     }
    
//     // Log the results to see the actual format
//     console.log('Employee Data:', results);
    
//     res.json(results);  // Return employee data as JSON
//   });
// });



// Save attendance route



// Enable promise API
const queryAsync = (sql, values) => {
  return new Promise((resolve, reject) => {
      con.query(sql, values, (err, results) => {
          if (err) {
              reject(err);
          } else {
              resolve(results);
          }
      });
  });
};



const upload = multer({
  limits: { fileSize: 50 * 1024 * 1024 },  // Max file size: 50MB
});





router.post('/attendance', async (req, res) => {
  console.log('Backend route hit');
  const attendanceData = req.body.attendanceData;

  // Validate the input data
  if (!attendanceData || !Array.isArray(attendanceData) || attendanceData.length === 0) {
    return res.status(400).json({ message: 'Invalid attendance data.' });
  }

  // Define the SQL queries
  const checkAttendanceQuery = `SELECT COUNT(*) AS count FROM attendance WHERE employee_id = ? AND MONTH(date) = MONTH(?) AND YEAR(date) = YEAR(?)`;
  const insertAttendanceQuery = `INSERT INTO attendance (employee_id, employee_name, date, day, time_in, time_out, hours_worked, delay, status) VALUES ?`;

  // Prepare an array to hold the attendance data
  const attendanceValues = [];

  // Loop through the provided attendance data
  for (const { employeeID, employeeName, date, day, timeIn, timeOut, hoursWorked, delay, status } of attendanceData) {

    // Check if attendance for the employee on the given date already exists
    const attendanceExists = await new Promise((resolve, reject) => {
      con.query(checkAttendanceQuery, [employeeID, date, date], (err, result) => {
        if (err) {
          console.error('Error checking attendance:', err);
          return reject(false);  // Return false if error occurs
        }
        resolve(result[0].count > 0);  // If count is greater than 0, attendance already exists
      });
    });

    // If attendance already exists for the employee on this date, send a message and stop further processing
    if (attendanceExists) {
      return res.status(400).json({
        message: `Attendance for Employee ID ${employeeID} on ${date} already exists.`
      });
    }

    // Add attendance data if it doesn't exist
    attendanceValues.push([employeeID, employeeName, date, day, timeIn, timeOut, hoursWorked, delay, status]);
  }

  try {
    // Insert attendance data (multiple rows at once)
    if (attendanceValues.length > 0) {
      await new Promise((resolve, reject) => {
        con.query(insertAttendanceQuery, [attendanceValues], (err, result) => {
          if (err) {
            console.error('Error inserting attendance data:', err);
            return reject({ message: 'Error inserting attendance data.' });
          }
          console.log(`${result.affectedRows} attendance records inserted successfully.`);
          resolve();
        });
      });
    }

    // Send a success response if everything goes well
    res.status(200).json({ message: 'Attendance processed successfully.' });
  } catch (error) {
    console.error('Unexpected error:', error);
    res.status(500).json({ message: 'An unexpected error occurred.' });
  }
});







// Helper function to calculate hours worked
// Helper function to calculate the hours worked
// router.post('/attendance', async (req, res) => {
//   const attendanceData = req.body.attendance;
//     console.log("Received body:", attendanceData);
//    // Attendance array from frontend
// console.log("body",attendanceData)
//   if (!attendanceData || !Array.isArray(attendanceData) || attendanceData.length === 0) {
//       return res.status(400).json({ message: 'Invalid attendance data.' });
//   }

//   // Start transaction
//   con.beginTransaction(function(err) {
//       if (err) {
//           return res.status(500).json({ message: 'Error starting transaction.' });
//       }

//       const insertQuery = `INSERT INTO attendance (employeeID, employeeName, date, day, timeIn, timeOut, hoursWorked, delay, status) 
//                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

//       // Use promises to track the completion of all queries
//       const insertPromises = attendanceData.map(attendance => {
//           return new Promise((resolve, reject) => {
//               const { employeeID, employeeName, date, day, timeIn, timeOut, hoursWorked, delay, status } = attendance;

//               con.query(insertQuery, [employeeID, employeeName, date, day, timeIn, timeOut, hoursWorked, delay, status], function(err, result) {
//                   if (err) {
//                       return reject(err);
//                   }
//                   resolve(result);
//               });
//           });
//       });

//       // Wait for all insert operations to complete
//       Promise.all(insertPromises)
//           .then(() => {
//               // Commit transaction
//               db.commit(function(err) {
//                   if (err) {
//                       return db.rollback(function() {
//                           res.status(500).json({ message: 'Error committing transaction.' });
//                       });
//                   }
//                   res.status(200).json({ message: 'Attendance submitted successfully' });
//               });
//           })
//           .catch(error => {
//               // Rollback transaction in case of any error
//               con.rollback(function() {
//                   console.error('Error inserting attendance data:', error);
//                   res.status(500).json({ message: 'Error inserting attendance data.' });
//               });
//           });
//   });
// });

// router.post('/attendance', async (req, res) => {
//   console.log('Backend route hit');
//   const attendanceData = req.body.attendanceData;

//   if (!attendanceData || !Array.isArray(attendanceData) || attendanceData.length === 0) {
//     return res.status(400).json({ message: 'Invalid attendance data.' });
//   }

//   try {
//     // Extract unique employee IDs
//     const employeeIDs = [...new Set(attendanceData.map((entry) => entry.employeeID))];

//     // Check if all employee IDs exist in the employee table
//     const query = `SELECT id FROM employee WHERE id IN (?)`;
//     con.query(query, [employeeIDs], (err, results) => {
//       if (err) {
//         console.error('Error querying employee table:', err);
//         return res.status(500).json({ message: 'Error checking employee data.' });
//       }

//       const existingEmployeeIDs = results.map((row) => row.id);
//       const missingEmployeeIDs = employeeIDs.filter((id) => !existingEmployeeIDs.includes(id));

//       if (missingEmployeeIDs.length > 0) {
//         return res.status(400).json({
//           message: `Missing employees with IDs: ${missingEmployeeIDs.join(', ')}`,
//         });
//       }

//       // Proceed to insert attendance data
//       const insertQuery = `
//         INSERT INTO attendance (employee_id, employee_name, date, day, time_in, time_out, hours_worked, delay, status)
//         VALUES ?
//       `;
//       const values = attendanceData.map(({ employeeID, employeeName, date, day, timeIn, timeOut, hoursWorked, delay, status }) => [
//         employeeID, employeeName, date, day, timeIn, timeOut, hoursWorked, delay, status,
//       ]);

//       con.query(insertQuery, [values], (err, result) => {
//         if (err) {
//           console.error('Error inserting attendance data:', err);
//           return res.status(500).json({ message: 'Error inserting attendance data.' });
//         }

//         res.status(200).json({ message: 'Attendance submitted successfully.' });
//       });
//     });
//   } catch (error) {
//     console.error('Unexpected error:', error);
//     res.status(500).json({ message: 'An unexpected error occurred.' });
//   }
// });

// router.post('/attendance', async (req, res) => {
//   console.log('Backend route hit');
//   const attendanceData = req.body.attendanceData;

//   // Validate the input data
//   if (!attendanceData || !Array.isArray(attendanceData) || attendanceData.length === 0) {
//     return res.status(400).json({ message: 'Invalid attendance data.' });
//   }

//   // Define the SQL queries
//   const insertEmployeeQuery = 'INSERT INTO employee (id, name) VALUES ? ON DUPLICATE KEY UPDATE name = VALUES(name)';
//   const insertAttendanceQuery = `INSERT INTO attendance (employee_id, employee_name, date, day, time_in, time_out, hours_worked, delay, status) VALUES ?`;

//   // Prepare arrays to hold employee and attendance data
//   const employeeValues = [];
//   const attendanceValues = [];

//   // Use a Set to track unique employees to avoid duplicates
//   const uniqueEmployees = new Set();

//   // Populate the values arrays
//   for (const { employeeID, employeeName, date, day, timeIn, timeOut, hoursWorked, delay, status } of attendanceData) {
//     // Add employee data if not already added (avoiding duplicates)
//     if (!uniqueEmployees.has(employeeID)) {
//       employeeValues.push([employeeID, employeeName]);
//       uniqueEmployees.add(employeeID);
//     }

//     // Add attendance data
//     attendanceValues.push([employeeID, employeeName, date, day, timeIn, timeOut, hoursWorked, delay, status]);
//   }

//   try {
//     // Insert employee data (only unique employees)
//     if (employeeValues.length > 0) {
//       await new Promise((resolve, reject) => {
//         con.query(insertEmployeeQuery, [employeeValues], (err, result) => {
//           if (err) {
//             console.error('Error inserting employees:', err);
//             return reject({ message: 'Error inserting employees.' });
//           }
//           console.log(`${result.affectedRows} employees inserted/updated successfully.`);
//           resolve();
//         });
//       });
//     }

//     // Insert attendance data (multiple rows at once)
//     if (attendanceValues.length > 0) {
//       await new Promise((resolve, reject) => {
//         con.query(insertAttendanceQuery, [attendanceValues], (err, result) => {
//           if (err) {
//             console.error('Error inserting attendance data:', err);
//             return reject({ message: 'Error inserting attendance data.' });
//           }
//           console.log(`${result.affectedRows} attendance records inserted successfully.`);
//           resolve();
//         });
//       });
//     }

//     // Send a success response
//     res.status(200).json({ message: 'Attendance processed successfully.' });
//   } catch (error) {
//     console.error('Unexpected error:', error);
//     res.status(500).json({ message: 'An unexpected error occurred.' });
//   }
// });





const app = express();



// router.post('/attendance', async (req, res) => {
//   const { attendance } = req.body;

//   if (!attendance) {
//     return res.status(400).json({ message: 'Attendance data is required.' });
//   }

//   const attendanceEntries = Object.entries(attendance).map(([employeeId, data]) => {
//     const { status, timeIn, timeOut, date } = data;

//     // Log the attendance data for debugging
//     console.log('Processing attendance entry:', { employeeId, status, timeIn, timeOut, date });

//     // Validate required fields
//     if (!employeeId || !status || !timeIn || !timeOut) {
//       return { error: `Missing required data for employee ${employeeId}` };  // Skip invalid entries
//     }

//     // Calculate hours worked
//     let hoursWorked = 0;
//     if (timeIn && timeOut) {
//       hoursWorked = calculateHoursWorked(timeIn, timeOut, date); // Pass the custom date (or null)
//       if (hoursWorked === 0) {
//         return { error: `Invalid time data for employee ${employeeId} on ${date || 'today'}` };  // Skip invalid entries
//       }
//     }

//     return {
//       employeeId,
//       status,
//       timeIn,
//       timeOut,
//       hoursWorked,
//       date: date || new Date().toISOString().slice(0, 10),  // Set custom date or default to today's date
//     };
//   });

//   try {
//     // Process attendance entries using the saveAttendance function
//     const promises = attendanceEntries.map(entry => {
//       // If there's an error in validation, return a rejected promise
//       if (entry.error) {
//         return Promise.reject(entry.error);
//       }
//       return saveAttendance(entry); // Process valid entries
//     });

//     // Wait for all records to be processed
//     await Promise.all(promises);

//     // Once all records are processed, send success response
//     res.json({ success: true, message: 'Attendance data saved successfully.' });

//   } catch (err) {
//     // Catch any errors during processing and send response once
//     console.error(err);
//     res.status(500).json({ message: 'Error saving attendance data', error: err });
//   }
// });

// // Save attendance function (modified)
// const saveAttendance = (entry) => {
//   const checkQuery = `SELECT * FROM attendance WHERE employee_id = ? AND date = ?`;

//   return new Promise((resolve, reject) => {
//     con.query(checkQuery, [entry.employeeId, entry.date], (err, results) => {
//       if (err) {
//         return reject(err); // Return error if query fails
//       }

//       if (results.length > 0) {
//         // Update attendance if already exists
//         const updateQuery = `
//             UPDATE attendance
//             SET status = ?, time_in = ?, time_out = ?, hours_worked = ?
//             WHERE employee_id = ? AND date = ?`;

//         con.query(updateQuery, [
//           entry.status, entry.timeIn, entry.timeOut, entry.hoursWorked, entry.employeeId, entry.date
//         ], (err) => {
//           if (err) {
//             return reject(err); // Return error if update fails
//           }
//           resolve(); // Success
//         });
//       } else {
//         // Insert new attendance record
//         const insertQuery = `
//             INSERT INTO attendance (employee_id, status, time_in, time_out, hours_worked, date)
//             VALUES (?, ?, ?, ?, ?, ?)`;

//         con.query(insertQuery, [
//           entry.employeeId, entry.status, entry.timeIn, entry.timeOut, entry.hoursWorked, entry.date
//         ], (err) => {
//           if (err) {
//             return reject(err); // Return error if insert fails
//           }
//           resolve(); // Success
//         });
//       }
//     });
//   });
// };


// Setup Multer storage


// Utility functions
const formatDate = (date) => {
  const dateObj = new Date(date);
  return dateObj.toISOString().split('T')[0];  // Format as YYYY-MM-DD
};

const getDayOfWeek = (date) => {
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  return days[new Date(date).getDay()];
};

const convertTo24HourFormat = (time) => {
  if (!time) return null;
  const [timePart, modifier] = time.split(' ');
  let [hours, minutes] = timePart.split(':').map(Number);

  if (modifier === 'PM' && hours !== 12) hours += 12;
  if (modifier === 'AM' && hours === 12) hours = 0;

  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
};

const calculateHoursWorked = (timeIn, timeOut) => {
  const [inHours, inMinutes] = timeIn.split(":").map(Number);
  const [outHours, outMinutes] = timeOut.split(":").map(Number);

  const timeInDate = new Date();
  const timeOutDate = new Date();
  timeInDate.setHours(inHours, inMinutes);
  timeOutDate.setHours(outHours, outMinutes);

  let diffMs = timeOutDate - timeInDate;
  if (diffMs < 0) return 0;
  return Math.round((diffMs / (1000 * 60 * 60)) * 100) / 100;
};

// Parse the uploaded Excel file and return the data
app.post('/api/admin/attendance', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded');
  }

  // Read the uploaded file
  const filePath = path.join(__dirname, 'uploads', req.file.filename);
  const workbook = xlsx.readFile(filePath);

  // Read the first sheet
  const sheet = workbook.Sheets[workbook.SheetNames[0]];

  // Convert the sheet to JSON (assuming the first row is headers)
  const sheetData = xlsx.utils.sheet_to_json(sheet, { header: 1 });

  const attendanceData = sheetData.slice(1).map((row) => {
    const employeeID = row[1]; // Assuming employee ID is in column 2
    const employeeName = row[2] || 'N/A'; // Assuming employee name is in column 3
    const date = formatDate(row[3]); // Assuming date is in column 4
    const day = getDayOfWeek(date);
    const timeIn = convertTo24HourFormat(row[5]);
    const timeOut = convertTo24HourFormat(row[6]);
    const hoursWorked = row[7] ? convertTimeFormatToDecimal(row[7]) : calculateHoursWorked(timeIn, timeOut);
    const delay = row[8] || '';
    const status = row[9] || 'Present';

    return {
      employeeID,
      employeeName,
      date,
      day,
      timeIn,
      timeOut,
      hoursWorked,
      delay,
      status,
    };
  });

  // Here you can save the attendanceData to the database
  // For now, we are just sending it back as a response
  res.json(attendanceData);
});









router.get('/logout', (req, res) => {
  res.clearCookie('token')
  return res.json({Status: true})
})
export { router as adminRouter };
