import React, { useState } from 'react';
import './style.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [values, setValues] = useState({
        email: '',
        password: ''
    });

    const [error, setError] = useState('');
    const [termsAccepted, setTermsAccepted] = useState(false);
    const navigate = useNavigate();

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setValues({ ...values, [name]: value });
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
   
        if (!termsAccepted) {
            setError('You must agree to the terms and conditions.');
            return;
        }
   
        console.log("Login Data: ", values); // Log the values to see the request format
    
        try {
            const response = await axios.post('http://localhost:3006/api/admin/adminlogin', values, {
                timeout: 5000
            });
        
            console.log("API Response: ", response);
            if (response.data.LoginStatus) {
                navigate('/dashboard');
            } else {
                setError(response.data.Error || 'Invalid login credentials.');
            }
        } catch (err) {
            console.error('Error during login:', err);
            if (err.response) {
                console.error("Response Data:", err.response.data);  // Log response data from backend
                setError(`Server Error: ${err.response.data.Error || 'Something went wrong.'}`);
            } else if (err.request) {
                setError('Network Error: Unable to reach the server.');
            } else {
                setError(`Error: ${err.message}`);
            }
        
        
        }
    };
   
    return (
        <div className="loginPage d-flex justify-content-center align-items-center min-vh-100 bg-light">
            <div className="loginForm bg-white shadow rounded p-4" style={{ width: '100%', maxWidth: '400px' }}>
                <h2 className="text-center mb-4">Login</h2>

                {error && <div className="alert alert-danger text-center" role="alert">{error}</div>}

                <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                        <label htmlFor="email" className="form-label">Email</label>
                        <input
                            type="email"
                            name="email"
                            id="email"
                            className="form-control"
                            placeholder="Enter your email"
                            value={values.email}
                            onChange={handleInputChange}
                            required
                        />
                    </div>

                    <div className="mb-3">
                        <label htmlFor="password" className="form-label">Password</label>
                        <input
                            type="password"
                            name="password"
                            id="password"
                            className="form-control"
                            placeholder="Enter your password"
                            value={values.password}
                            onChange={handleInputChange}
                            required
                        />
                    </div>

                    <div className="form-check mb-3">
                        <input
                            type="checkbox"
                            name="terms"
                            id="terms"
                            className="form-check-input"
                            checked={termsAccepted}
                            onChange={(e) => setTermsAccepted(e.target.checked)}
                            required
                        />
                        <label htmlFor="terms" className="form-check-label">
                            I agree to the terms & conditions
                        </label>
                    </div>

                    <button type="submit" className="btn btn-primary w-100">Log in</button>
                </form>
            </div>
        </div>
    );
};

export default Login;
