import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const EmployeeDashboard = () => {
  const [attendanceData, setAttendanceData] = useState([]);
  const [month, setMonth] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [currentPage, setCurrentPage] = useState(1); // Track current page
  const [recordsPerPage] = useState(30); // 25 records per page

  const employeeId = localStorage.getItem('employeeId');
  const navigate = useNavigate();

  useEffect(() => {
    if (employeeId) {
      fetchAttendanceData(employeeId);
    } else {
      navigate('/login'); // Redirect to login page if employeeId is not found
    }
  }, [employeeId, navigate]);

  // Fetch attendance data from the API
  const fetchAttendanceData = async (employeeId) => {
    setLoading(true);
    setError('');
  
    try {
      const response = await axios.get(`http://localhost:3006/api/admin/employeedashboard/${employeeId}`);
  
      if (response.data.Status) {
        setAttendanceData(response.data.Attendance); // Set the fetched data
      } else {
        setError('No attendance records found for this employee.');
      }
      setLoading(false);
    } catch (err) {
      setLoading(false);
      setError('Error fetching attendance data. Please try again later.');
      console.error('Error fetching attendance:', err);
    }
  };

  // Handle the month change and filter data accordingly
  const handleMonthChange = (e) => {
    setMonth(e.target.value);
  };

  // Handle pagination
  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  // Get the current records for the page
  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords = attendanceData.slice(indexOfFirstRecord, indexOfLastRecord);

  // Handle logout
  const handleLogout = () => {
    localStorage.removeItem('employeeId');
    navigate('/employeelogin'); // Redirect to login page
  };

  return (
    <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh', width: '100vw', backgroundColor: '#f8f9fa' }}>
      <div className="card shadow-lg p-4" style={{ maxWidth: '1000px', width: '100%', backgroundColor: 'grey', color: 'white', borderRadius: '10px' }}>
        <h2 className="text-center mb-4">Employee Dashboard</h2>

        {error && <div className="alert alert-danger">{error}</div>}

        <div className="mb-3">
          <label htmlFor="month" className="form-label">Select Month:</label>
          <input
            type="month"
            className="form-control"
            id="month"
            value={month}
            onChange={handleMonthChange}
            required
            style={{ borderRadius: '5px' }}
          />
        </div>

        {/* Logout Button */}
        <div className="mb-3 text-center">
          <button onClick={handleLogout} className="btn btn-danger">Logout</button>
        </div>

        {loading ? (
          <div className="text-center">
            <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...
          </div>
        ) : (
          <div>
            <h4>Attendance for {month ? month : 'All Time'}</h4>
            <div style={{ maxHeight: '500px', overflowY: 'auto' }}> {/* Scrollable container */}
              <table className="table table-bordered table-hover mt-3">
                <thead>
                  <tr>
                    <th>Employee Name</th>
                    <th>Date</th>
                    <th>Day</th>
                    <th>Status</th>
                    <th>Time In</th>
                    <th>Time Out</th>
                    <th>Hours Worked</th>
                    <th>Delay</th>
                  </tr>
                </thead>
                <tbody>
                  {currentRecords.length > 0 ? (
                    currentRecords.map((record, index) => (
                      <tr key={index}>
                        <td>{record.employee_name}</td>
                        <td>{new Date(record.date).toLocaleDateString()}</td> {/* Shortened date format */}
                        <td>{record.day}</td>
                        <td>{record.status}</td>
                        <td>{record.time_in}</td>
                        <td>{record.time_out}</td>
                        <td>{record.hours_worked}</td>
                        <td>{record.delay}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="8" className="text-center">No attendance records for this month or no matches found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            {/* Pagination Controls */}
            <div className="d-flex justify-content-center mt-4">
              <nav>
                <ul className="pagination">
                  {/* Previous Button */}
                  <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                    <button className="page-link" onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1}>Previous</button>
                  </li>
                  {/* Page Numbers */}
                  {[...Array(Math.ceil(attendanceData.length / recordsPerPage))].map((_, index) => (
                    <li className={`page-item ${currentPage === index + 1 ? 'active' : ''}`} key={index}>
                      <button className="page-link" onClick={() => handlePageChange(index + 1)}>
                        {index + 1}
                      </button>
                    </li>
                  ))}
                  {/* Next Button */}
                  <li className={`page-item ${currentPage === Math.ceil(attendanceData.length / recordsPerPage) ? 'disabled' : ''}`}>
                    <button className="page-link" onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === Math.ceil(attendanceData.length / recordsPerPage)}>Next</button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EmployeeDashboard;
