import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditEmployee = () => {
  const { id } = useParams(); // Get the employee ID from the URL params
  const [employee, setEmployee] = useState({
    name: '',
    email: '',
    salary: '',
    address: '',
    department_name: '', // department_name to store the selected department
  });
  const [departments, setDepartments] = useState([]); // Store list of departments
  const [error, setError] = useState(''); // To display errors
  const [loading, setLoading] = useState(false); // For loading state
  const navigate = useNavigate(); // For navigation after submission

  // Fetch employee and department data
  useEffect(() => {
    if (!id) {
      setError('Invalid ID.');
      return;
    }

    const fetchData = async () => {
      try {
        setLoading(true); // Start loading state
        // Fetch employee data
        const employeeResult = await axios.get(`http://localhost:3006/api/admin/employee/${id}`);
        if (employeeResult.data?.Result?.length > 0) {
          const employeeData = employeeResult.data.Result[0];
          setEmployee({
            name: employeeData.name || '',
            email: employeeData.email || '',
            address: employeeData.address || '',
            salary: employeeData.salary || '',
            department_name: employeeData.department_name || '',
          });
        } else {
          setError('Employee not found.');
        }

        // Fetch department data
        const departmentResult = await axios.get('http://localhost:3006/api/admin/department');
        setDepartments(departmentResult.data || []); // Ensure departments is an array
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Error fetching employee or department data.');
      } finally {
        setLoading(false); // Stop loading state
      }
    };

    fetchData();
  }, [id]);

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent form default submission

    // Basic validation
    if (!employee.name || !employee.email || !employee.salary || !employee.address ) {
      setError('Please fill in all fields.');
      return;
    }

    setLoading(true); // Start loading during the submit action

    // Update employee in the database
    axios
      .put(`http://localhost:3006/api/admin/edit_employee/${id}`, employee)
      .then((result) => {
        if (result.data?.Status) {
          navigate('/dashboard/employee'); // Navigate to employee list page
        } else {
          setError(result.data?.Error || 'Failed to update employee.');
        }
      })
      .catch((err) => {
        console.error('Error updating employee:', err);
        setError('Error updating employee.');
      })
      .finally(() => {
        setLoading(false); // Stop loading after submission
      });
  };

  return (
    <div className="d-flex justify-content-center align-items-center mt-3">
      <div className="p-3 rounded w-50 border">
        <h3 className="text-center">Edit Employee</h3>
        {error && <div className="alert alert-danger">{error}</div>} {/* Display error message */}
        {loading && <div className="text-center">Loading...</div>} {/* Display loading message */}
        <form className="row g-1" onSubmit={handleSubmit}>
          <div className="col-12">
            <label htmlFor="inputName" className="form-label">
              Name
            </label>
            <input
              type="text"
              className="form-control rounded-0"
              id="inputName"
              placeholder="Enter Name"
              value={employee.name}
              onChange={(e) => setEmployee({ ...employee, name: e.target.value })}
            />
          </div>
          <div className="col-12">
            <label htmlFor="inputEmail" className="form-label">
              Email
            </label>
            <input
              type="email"
              className="form-control rounded-0"
              id="inputEmail"
              placeholder="Enter Email"
              autoComplete="off"
              value={employee.email}
              onChange={(e) => setEmployee({ ...employee, email: e.target.value })}
            />
          </div>
          <div className="col-12">
            <label htmlFor="inputSalary" className="form-label">
              Salary
            </label>
            <input
              type="text"
              className="form-control rounded-0"
              id="inputSalary"
              placeholder="Enter Salary"
              value={employee.salary}
              onChange={(e) => setEmployee({ ...employee, salary: e.target.value })}
            />
          </div>
          <div className="col-12">
            <label htmlFor="inputAddress" className="form-label">
              Address
            </label>
            <input
              type="text"
              className="form-control rounded-0"
              id="inputAddress"
              placeholder="1234 Main St"
              value={employee.address}
              onChange={(e) => setEmployee({ ...employee, address: e.target.value })}
            />
          </div>
          {/* <div className="col-12">
            <label htmlFor="department" className="form-label">
              Department
            </label>
            <select
              className="form-control rounded-0"
              id="department"
              value={employee.department_name}
              onChange={(e) => setEmployee({ ...employee, department_name: e.target.value })}
            >
              <option value="">Select Department</option>
              {Array.isArray(departments) && departments.length > 0 ? (
                departments.map((dept) => (
                  <option key={dept.id} value={dept.name}>
                    {dept.name}
                  </option>
                ))
              ) : (
                <option value="">No departments available</option> // Fallback when no departments are available
              )}
            </select>
          </div> */}

          <div className="col-12">
            <button type="submit" className="btn btn-primary w-100" disabled={loading}>
              {loading ? 'Updating...' : 'Edit Employee'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditEmployee;
