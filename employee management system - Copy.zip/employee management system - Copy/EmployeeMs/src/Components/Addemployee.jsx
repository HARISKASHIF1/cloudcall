import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const AddEmployee = () => {
  const [employee, setEmployee] = useState({
    id: "", // Employee ID
    name: "",
    email: "",
    password: "",
    salary: "",
    address: "",
    contact_number: "",
    image: null,
    cnic_image: null,
  });

  const navigate = useNavigate();

  // Function to generate password from name and contact number
  const generatePassword = (name, contactNumber) => {
    const namePart = name.replace(/\s+/g, "").toLowerCase();
    return `${namePart}${contactNumber}`;
  };

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value, type, files } = e.target;
    setEmployee((prevState) => ({
      ...prevState,
      [name]: type === "file" ? files[0] : value,
    }));
  };

  // Validate employee fields
  const validateFields = () => {
    const {id, name, email, salary, address, contact_number, image, cnic_image } = employee;
    if (!id ||!name || !email || !salary || !address || !contact_number || !image || !cnic_image) {
      alert("All fields are required.");
      return false;
    }
    return true;
  };

  // Prepare FormData and make the POST request
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate fields before submission
    if (!validateFields()) return;

    const password = generatePassword(employee.name, employee.contact_number);
    const formData = new FormData();
    formData.append("id", employee.id);
    formData.append("name", employee.name);
    formData.append("email", employee.email);
    formData.append("password", password);
    formData.append("salary", employee.salary);
    formData.append("address", employee.address);
    formData.append("contact_number", employee.contact_number);
    formData.append("image", employee.image);
    formData.append("cnic_image", employee.cnic_image);

    try {
      const response = await axios.post("http://localhost:3006/api/admin/add_employee", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      if (response.data.Status) {
        navigate("/dashboard/employee");
      } else {
        alert(response.data.Error || "Error adding employee.");
      }
    } catch (err) {
      console.error("Error during employee addition:", err);
      alert("Error adding employee.");
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center mt-3">
      <div className="p-3 rounded w-50 border">
        <h3 className="text-center">Add Employee</h3>
        <form className="row g-1" onSubmit={handleSubmit}>
          {/* Employee ID */}
          <div className="col-12">
            <label htmlFor="inputid" className="form-label">Employee ID</label>
            <input
              type="text"
              className="form-control rounded-0"
              id="inputid"
              name="id"
              value={employee.id}
              onChange={handleInputChange}
              placeholder="Enter Employee ID"
              required
            />
          </div>

          {/* Name */}
          <div className="col-12">
            <label htmlFor="inputName" className="form-label">Name</label>
            <input
              type="text"
              className="form-control rounded-0"
              id="inputName"
              name="name"
              value={employee.name}
              onChange={handleInputChange}
              placeholder="Enter Name"
              required
            />
          </div>

          {/* Email */}
          <div className="col-12">
            <label htmlFor="inputEmail" className="form-label">Email</label>
            <input
              type="email"
              className="form-control rounded-0"
              id="inputEmail"
              name="email"
              value={employee.email}
              onChange={handleInputChange}
              placeholder="Enter Email"
              required
            />
          </div>

          {/* Password (Auto-generated) */}
          <div className="col-12">
            <label htmlFor="inputPassword" className="form-label">Password (auto-generated)</label>
            <input
              type="text"
              className="form-control rounded-0"
              id="inputPassword"
              value={employee.password} // Display auto-generated password
              disabled
            />
          </div>

          {/* Salary */}
          <div className="col-12">
            <label htmlFor="inputSalary" className="form-label">Salary</label>
            <input
              type="text"
              className="form-control rounded-0"
              id="inputSalary"
              name="salary"
              value={employee.salary}
              onChange={handleInputChange}
              placeholder="Enter Salary"
              required
            />
          </div>

          {/* Address */}
          <div className="col-12">
            <label htmlFor="inputAddress" className="form-label">Address</label>
            <input
              type="text"
              className="form-control rounded-0"
              id="inputAddress"
              name="address"
              value={employee.address}
              onChange={handleInputChange}
              placeholder="Enter Address"
              required
            />
          </div>

          {/* Contact Number */}
          <div className="col-12">
            <label htmlFor="inputContactNumber" className="form-label">Contact Number</label>
            <input
              type="text"
              className="form-control rounded-0"
              id="inputContactNumber"
              name="contact_number"
              value={employee.contact_number}
              onChange={handleInputChange}
              placeholder="Enter Contact Number"
              required
            />
          </div>

          {/* Employee Image */}
          <div className="col-12 mb-3">
            <label className="form-label" htmlFor="inputEmployeeImage">Employee Photo</label>
            <input
              type="file"
              className="form-control rounded-0"
              id="inputEmployeeImage"
              name="image"
              accept="image/*"
              onChange={handleInputChange}
              required
            />
          </div>

          {/* CNIC Image */}
          <div className="col-12 mb-3">
            <label className="form-label" htmlFor="inputCnicImage">CNIC Photo</label>
            <input
              type="file"
              className="form-control rounded-0"
              id="inputCnicImage"
              name="cnic_image"
              accept="image/*"
              onChange={handleInputChange}
              required
            />
          </div>

          {/* Submit Button */}
          <div className="col-12 pt-5">
            <button type="submit" className="btn btn-primary w-100">Add Employee</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddEmployee;
