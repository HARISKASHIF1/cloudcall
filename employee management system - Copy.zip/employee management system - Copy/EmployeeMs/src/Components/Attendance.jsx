import React, { useState, useEffect } from 'react';
import axios from 'axios';
import * as XLSX from 'xlsx';
import './style.css';

const ITEMS_PER_PAGE = 100;

const Attendance = () => {
    const [employees, setEmployees] = useState([]);
    const [attendanceData, setAttendanceData] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [monthFilter, setMonthFilter] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [file, setFile] = useState(null);

    useEffect(() => {
        // Hide the success message after 5 seconds
        if (success) {
            const timer = setTimeout(() => {
                setSuccess('');
            }, 5000); // Hide after 5 seconds

            return () => clearTimeout(timer);
        }

        // Hide the error message after 5 seconds
        if (error) {
            const timer = setTimeout(() => {
                setError('');
            }, 5000); // Hide after 5 seconds

            return () => clearTimeout(timer);
        }
    }, [error, success]);

    const handleFileUpload = (e) => {
        const uploadedFile = e.target.files[0];
        setFile(uploadedFile);

        if (uploadedFile) {
            const reader = new FileReader();
            reader.onload = handleFileRead;
            reader.onerror = handleFileReadError;
            reader.readAsArrayBuffer(uploadedFile);
        }
    };

    const handleFileRead = (event) => {
        try {
            const data = new Uint8Array(event.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const sheetData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

            if (sheetData.length === 0) {
                setError('The file is empty.');
                return;
            }

            const updatedAttendanceData = parseAttendanceData(sheetData);
            setAttendanceData(updatedAttendanceData);
        } catch (error) {
            setError('Error processing the file.');
            console.error(error);
        }
    };

    const handleFileReadError = (error) => {
        setError('Error reading the file.');
        console.error(error);
    };

    const parseAttendanceData = (sheetData) => {
        return sheetData.slice(1).map((row) => {
            if (row[1]) {
                const employeeID = row[1];
                const employeeName = row[2] || 'N/A';
                const date = row[3];
                const formattedDate = formatDate(date);
                const day = getDayOfWeek(formattedDate);
                const timeIn = convertTo24HourFormat(XLSX.SSF.format("h:mm AM/PM", row[5]));
                const timeOut = convertTo24HourFormat(XLSX.SSF.format("h:mm AM/PM", row[6]));
                const hoursWorked = row[7] ? convertTimeFormatToDecimal(row[7]) : calculateHoursWorked(timeIn, timeOut);
                const delay = row[8] || '';
                const status = row[9] || 'Present';

                return {
                    employeeID,
                    employeeName,
                    date: formattedDate,
                    day,
                    timeIn,
                    timeOut,
                    hoursWorked,
                    delay,
                    status,
                };
            }
            return null;
        }).filter(Boolean);
    };

    const filteredAttendanceData = () => {
        let filteredData = [...attendanceData];

        if (monthFilter) {
            filteredData = filteredData.filter(item => item.date.startsWith(monthFilter));
        }

        if (searchTerm) {
            filteredData = filteredData.filter(item =>
                item.employeeID.toString().includes(searchTerm) ||
                item.employeeName.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        return filteredData;
    };

    const handleExport = () => {
        const filteredData = filteredAttendanceData();

        if (filteredData.length === 0) {
            alert('No data available to export.');
            return;
        }

        const exportData = filteredData.map(item => ({
            'Employee ID': item.employeeID,
            'Name': item.employeeName,
            'Date': item.date,
            'Day': item.day,
            'Time In': item.timeIn,
            'Time Out': item.timeOut,
            'Hours Worked': item.hoursWorked,
            'Delay': item.delay,
            'Status': item.status,
        }));

        const worksheet = XLSX.utils.json_to_sheet(exportData);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Attendance');
        const fileName = `Attendance_${searchTerm}_${monthFilter || 'AllMonths'}.xlsx`;
        XLSX.writeFile(workbook, fileName);
    };

    const handleSubmit = () => {
        const filteredData = filteredAttendanceData();
        if (filteredData.length === 0) {
            setError('No data to submit.');
            return;
        }
    
        axios.post('http://localhost:3006/api/admin/attendance', { attendanceData: filteredData }, { headers: { 'Content-Type': 'application/json' } })
            .then((response) => {
                if (response.data.message) {
                    // If backend returns a specific message, set it as an error (e.g., attendance already exists)
                    // setError(response.data.message);
                    setSuccess('Attendance data submitted successfully.');
                } else {
                    // If submission is successful, clear the error and show success message
               
                    setError('');
                }
            })
            .catch((error) => {
                if (error.response && error.response.status === 400) {
                    // If a 400 error occurs (e.g., attendance already exists), show a specific error message
                    setError('Attendance already exists.');
                } else {
                    // For other errors, display a more general error message
                    setError('Failed to submit attendance data.');
                }
                setSuccess('');
                console.error('Error details:', error.response || error.message || error);
            });
    };
    

    const formatDate = (date) => {
        const dateObj = new Date(date);
        if (isNaN(dateObj)) {
            const parts = date.split('/');
            if (parts.length === 3) {
                return new Date(parts[2], parts[1] - 1, parts[0]).toISOString().split('T')[0];
            }
            return '';
        }
        return dateObj.toISOString().split('T')[0];
    };

    const getDayOfWeek = (date) => {
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return days[new Date(date).getDay()];
    };

    const convertTo24HourFormat = (time) => {
        if (!time) return '';
        const [timePart, modifier] = time.split(' ');
        let [hours, minutes] = timePart.split(':').map(Number);

        if (modifier === 'PM' && hours !== 12) hours += 12;
        if (modifier === 'AM' && hours === 12) hours = 0;

        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    };

    const convertTimeFormatToDecimal = (timeStr) => {
        const match = /\d+h,\s*\d+m/.exec(timeStr);
        if (match) {
            const [hours, minutes] = match[0].split(/h|,/).map(Number);
            return hours + minutes / 60;
        }
        return 0;
    };

    const calculateHoursWorked = (timeIn, timeOut) => {
        const [inHours, inMinutes] = timeIn.split(":").map(Number);
        const [outHours, outMinutes] = timeOut.split(":").map(Number);

        const timeInDate = new Date();
        const timeOutDate = new Date();
        timeInDate.setHours(inHours, inMinutes);
        timeOutDate.setHours(outHours, outMinutes);

        const diffMs = timeOutDate - timeInDate;
        return diffMs > 0 ? Math.round((diffMs / (1000 * 60 * 60)) * 100) / 100 : 0;
    };

    const totalPages = Math.ceil(filteredAttendanceData().length / ITEMS_PER_PAGE);

    return (
        <div className="attendancePage container mt-5">
            <h2 className="text-center mb-4">Attendance</h2>

            {error && <div className="alert alert-danger">{error}</div>}
            {success && <div className="alert alert-success">{success}</div>}

            <div className="filters mb-4">
                <input
                    type="month"
                    value={monthFilter}
                    onChange={(e) => setMonthFilter(e.target.value)}
                    className="form-control"
                    placeholder="Filter by Month"
                />

                <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="form-control mt-2"
                    placeholder="Search by Employee ID or Name"
                />

                <input
                    type="file"
                    accept=".xlsx, .xls, .csv"
                    onChange={handleFileUpload}
                    className="form-control mt-2"
                />
            </div>

            <div className="actions mb-4">
                <button onClick={handleExport} className="btn btn-success me-2">
                    Export Data
                </button>
                <button onClick={handleSubmit} className="btn btn-primary">
                    Submit Data
                </button>
            </div>

            <table className="table table-bordered">
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Name</th>
                        <th>Date</th>
                        <th>Day</th>
                        <th>Time In</th>
                        <th>Time Out</th>
                        <th>Hours Worked</th>
                        <th>Delay</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredAttendanceData().slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE).map((item, index) => (
                        <tr key={index}>
                            <td>{item.employeeID}</td>
                            <td>{item.employeeName}</td>
                            <td>{item.date}</td>
                            <td>{item.day}</td>
                            <td>{item.timeIn}</td>
                            <td>{item.timeOut}</td>
                            <td>{item.hoursWorked}</td>
                            <td>{item.delay}</td>
                            <td>{item.status}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <div className="pagination mt-4">
                <button onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))} className="btn btn-secondary" disabled={currentPage === 1}>
                    Previous
                </button>
                <span className="mx-2">{currentPage} of {totalPages}</span>
                <button onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))} className="btn btn-secondary" disabled={currentPage === totalPages}>
                    Next
                </button>
            </div>
        </div>
    );
};

export default Attendance;
