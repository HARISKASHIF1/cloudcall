import React, { useState } from 'react';  // Import useState to handle input
import { useNavigate } from 'react-router-dom';  // Import useNavigate
import axios from 'axios';  // Import axios for API calls

const Adddepartment = () => {
  const [department, setDepartment] = useState('');  // Correct state name to 'department'
  const navigate = useNavigate();  // Hook to navigate to other pages

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();  // Prevent default form submission behavior

    // Send POST request to backend API
    axios.post('http://localhost:3006/api/admin/add_department', { department: department })  // Corrected body
      .then(result => {
        if (result.data.Status) {
          // If department added successfully, navigate to the department page
          navigate("/dashboard/department");
        } else {
          // If there was an error, display the error message
          alert(result.data.Error || 'An error occurred while adding the department.');
        }
      })
      .catch(err => {
        console.log("Error during department addition:", err);
        alert('An error occurred while adding the department.');
      });
  };

  return (
    <div className="d-flex justify-content-center align-items-center vh-75">
      <div className="p-3 d-flex justify-content-center rounded w-60 border">
        <h2>ADD DEPARTMENT</h2>

        {/* Form for adding department */}
        <form onSubmit={handleSubmit}>  {/* Connect form to handleSubmit */}
          <div className="mb-3">
            <label htmlFor="department">Department:</label>
            <input
              type="text"
              id="department"  // Proper id for the input
              placeholder="Enter Department"
              value={department}  // Bind input to the department state
              onChange={(e) => setDepartment(e.target.value)}  // Update state on input change
              className="form-control rounded"
              required
            />
          </div>
          <button type="submit" className="btn btn-success w-100 rounded-0">
            Add Department
          </button>
        </form>
      </div>
    </div>
  );
};

export default Adddepartment;
