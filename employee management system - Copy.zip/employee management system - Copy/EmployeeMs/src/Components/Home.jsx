import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const navigate = useNavigate(); // Create the navigate instance
  const [employeeData, setEmployeeData] = useState({
    totalEmployees: 0,
    departments: [], // Ensure this is initialized as an empty array
  });
  const [loading, setLoading] = useState(true); // Loading state
  const [error, setError] = useState(null); // Error state

  useEffect(() => {
    // Fetching data for employees and departments from the API
    const fetchDashboardData = async () => {
      try {
        const response = await axios.get('http://localhost:3006/api/admin/dashboard');
        console.log('API Response:', response.data); // Log the response
        if (response.data.Status) {
          setEmployeeData({
            totalEmployees: response.data.totalEmployees,
            departments: response.data.departments || [], // Ensure departments is always an array
          });
        } else {
          setError('Error fetching data: ' + response.data.Error);
        }
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Error fetching data. Please try again later.');
      } finally {
        setLoading(false); // Set loading to false after data is fetched
      }
    };

    fetchDashboardData();
  }, []);

  const handleLogout = async () => {
    try {
      const result = await axios.get('http://localhost:3006/api/admin/logout');
      if (result.data.Status) {
        localStorage.removeItem('valid'); // Remove the local storage item
        navigate('/adminLogin'); // Redirect to login page
      }
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  return (
    <div className="container-fluid">
      <div className="row flex-nowrap">
        {/* Sidebar */}
        <div className="col-auto col-md-3 col-lg-2 px-0 bg-dark rounded-end shadow-lg" id="sidebar">
          <div className="d-flex flex-column align-items-center align-items-sm-start px-3 pt-4 text-white min-vh-100">
            <a href="/" className="d-flex align-items-center pb-3 mb-md-3 mt-md-3 text-white text-decoration-none">
              <span className="fs-4 fw-bold d-none d-sm-inline">Admin Dashboard</span>
            </a>

            <ul className="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start w-100" id="menu">
              <li className="w-100">
                <Link to="/dashboard" className="nav-link text-white px-0 py-2 align-middle w-100">
                  <i className="fs-4 bi-house-door"></i>
                  <span className="ms-2 d-none d-sm-inline">Dashboard</span>
                </Link>
              </li>
              <li className="w-100">
                <Link to="/dashboard/employee" className="nav-link text-white px-0 py-2 align-middle w-100">
                  <i className="fs-4 bi-person-lines-fill"></i>
                  <span className="ms-2 d-none d-sm-inline">Manage Employees</span>
                </Link>
              </li>
              <li className="w-100">
                <Link to="/dashboard/department" className="nav-link text-white px-0 py-2 align-middle w-100">
                  <i className="fs-4 bi-building"></i>
                  <span className="ms-2 d-none d-sm-inline">Department</span>
                </Link>
              </li>
              <li className="w-100">
                <Link to="/dashboard/attendance" className="nav-link text-white px-0 py-2 align-middle w-100">
                  <i className="fs-4 bi-calendar-check"></i>
                  <span className="ms-2 d-none d-sm-inline">Attendance</span>
                </Link>
              </li>
              <li className="w-100" onClick={handleLogout}>
                <Link className="nav-link px-0 align-middle text-white">
                  <i className="fs-4 bi-power ms-2"></i>
                  <span className="ms-2 d-none d-sm-inline">Logout</span>
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Main Content */}
        <div className="col px-4 py-3" id="main-content">
          {/* Error Message */}
          {error && <div className="alert alert-danger">{error}</div>}

          {/* Loading Message */}
          {loading && <p>Loading...</p>}

          {/* Dashboard Cards */}
          {!loading && !error && (
            <div className="row">
              {/* Total Employees Card */}
              <div className="col-md-8 mb-4">
                <div className="card total-employees shadow-lg w-100">
                  <div className="card-body w-100">
                    <h5 className="card-title text-center">Total Employees</h5>
                    <h2 className="text-center">{employeeData.totalEmployees}</h2>
                  </div>
                </div>
              </div>

             
              {/* {employeeData.departments.length > 0 ? (
                employeeData.departments.map((dept) => (
                  <div className="col-md-4 mb-4" key={dept.id}>
                    <div className="card shadow-lg w-75">
                      <div className="card-body">
                        <h5 className="card-title text-center">{dept.name}</h5>
                        <h2 className="text-center">{dept.employeeCount}</h2>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-md-12">
                  <div className="alert alert-info">No departments available.</div>
                </div>
              )} */}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
