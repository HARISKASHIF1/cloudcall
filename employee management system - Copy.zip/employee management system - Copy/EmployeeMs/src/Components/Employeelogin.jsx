import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const EmployeeLogin = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Handle form input changes
  const handleInputChange = (setter) => (e) => setter(e.target.value);

  // Handle form submission for login
  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { data } = await axios.post('http://localhost:3006/api/admin/employeelogin', { email, password });
      setLoading(false);

      if (data.Status) {
        // Call onLogin callback and navigate to employee dashboard
        if (typeof onLogin === 'function') {
          onLogin(data.Employee);
          localStorage.setItem('employeeId', data.Employee.id);
          navigate('/employeedashboard');
        }
      } else {
        setError(data.Error || 'Login failed. Please try again.');
      }
    } catch (err) {
      setLoading(false);
      console.error('Login error:', err);
      setError(err.response?.data?.Error || 'An error occurred. Please try again.');
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center" style={styles.container}>
      <div className="card shadow-lg p-4" style={styles.card}>
        <h2 className="text-center mb-4">Employee Login</h2>

        {error && <div className="alert alert-danger">{error}</div>}

        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <input
              type="email"
              className="form-control"
              placeholder="Employee Email"
              value={email}
              onChange={handleInputChange(setEmail)}
              required
              style={styles.input}
            />
          </div>
          <div className="mb-3">
            <input
              type="password"
              className="form-control"
              placeholder="Password"
              value={password}
              onChange={handleInputChange(setPassword)}
              required
              style={styles.input}
            />
          </div>
          <div className="d-grid gap-2">
            <button type="submit" className="btn btn-light" disabled={loading} style={styles.button}>
              {loading ? (
                <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
              ) : (
                'Login'
              )}
            </button>
          </div>
        </form>

        {/* <div className="text-center mt-3">
          <small>
            Don't have an account? <a href="/register" style={styles.registerLink}>Register</a>
          </small>
        </div> */}
      </div>
    </div>
  );
};

const styles = {
  container: {
    minHeight: '100vh',
    width: '100vw',
    backgroundColor: '#f8f9fa',
  },
  card: {
    maxWidth: '400px',
    width: '100%',
    backgroundColor: 'grey',
    color: 'white',
    borderRadius: '10px',
  },
  input: {
    borderRadius: '5px',
  },
  button: {
    borderRadius: '5px',
  },
  registerLink: {
    color: '#ffffff',
  },
};

export default EmployeeLogin;
