import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Department = () => {
  const [department, setDepartment] = useState([]);
  const [error, setError] = useState(null);  // To handle errors
  const [loading, setLoading] = useState(true);  // Loading state

  useEffect(() => {
    // Fetching departments from the backend
    axios.get('http://localhost:3006/api/admin/department')
      .then(result => {
        setLoading(false);  // Set loading to false after data is fetched
        if (result.data.Status) {
          setDepartment(result.data.Result);  // Set the departments to state
        } else {
          setError('Error fetching departments: ' + result.data.Error);  // Show error message if Status is false
        }
      })
      .catch(err => {
        setLoading(false);  // Set loading to false if there's an error
        setError('API error: ' + err.message);  // Show error message in case of network or server issues
        console.log("API error:", err);
      });
  }, []);  // Empty dependency array to run the effect only once

  return (
    <div className="px-5 mt-3">
      <div className="d-flex justify-content-center">
        <h3>Department List</h3>
      </div>
      <Link to="/dashboard/add-department" className="btn btn-success">Add Department</Link>
      <div className="mt-3">
        {/* Display loading message while data is being fetched */}
        {loading && <div className="alert alert-info">Loading departments...</div>}

        {/* Display error if any */}
        {error && <div className="alert alert-danger">{error}</div>}

        <table className="table">
          <thead>
            <tr>
              <th>ID</th>  {/* Optionally add ID column */}
              <th>Name</th>
            </tr>
          </thead>
          <tbody>
            {department.length === 0 ? (
              <tr>
                <td colSpan="2" className="text-center">No departments found</td>
              </tr>
            ) : (
              department.map((d) => (
                <tr key={d.id}>  {/* Ensure a unique key for each row */}
                  <td>{d.id}</td>  {/* Display the department ID */}
                  <td>{d.name}</td>  {/* Display department name */}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Department;
