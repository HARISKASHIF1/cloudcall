import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import LazyLoad from 'react-lazyload';  // Ensure LazyLoad is imported

const Employee = () => {
  const [employee, setEmployee] = useState([]); // State to store employee data
  const [error, setError] = useState(null); // State to store error messages if any

  // Fetch all employees when the component is mounted
  useEffect(() => {
    axios
      .get("http://localhost:3006/api/admin/employee")
      .then((response) => {
        if (response.data.Status) {
          setEmployee(response.data.Employee || []); // Default to empty array if Employee is undefined
        } else {
          setError("Error fetching employees: " + response.data.Error);
        }
      })
      .catch((error) => {
        console.error("Error fetching employees:", error);
        setError("Error fetching employees.");
      });
  }, []); // Empty dependency array to run only once on mount

  // Handle employee deletion
  const handleDelete = (id) => {
    console.log("Deleting employee with ID:", id);

    const confirmDelete = window.confirm("Are you sure you want to delete this employee?");

    if (confirmDelete) {
      axios
        .delete(`http://localhost:3006/api/admin/delete_employee/${id}`)
        .then((response) => {
          if (response.data.Status) {
            setEmployee((prevEmployees) => prevEmployees.filter((emp) => emp.id !== id));
          } else {
            alert("Failed to delete employee: " + response.data.Error);
            console.error("Deletion failed with error: ", response.data.Error);
          }
        })
        .catch((error) => {
          console.error("Error deleting employee:", error);
          alert("Error deleting employee. Please try again.");
        });
    }
  };

  return (
    <div className="px-5 mt-3">
      <div className="d-flex justify-content-center">
        <h3>Employee List</h3>
      </div>

      {/* Link to Add Employee page */}
      <Link to="/dashboard/add-employee" className="btn btn-success mb-3">
        Add Employee
      </Link>

      {/* Error handling */}
      {error && <div className="alert alert-danger">{error}</div>}

      {/* Employee Table */}
      <div className="mt-3">
        {employee.length > 0 ? (
          <table className="table table-bordered">
            <thead>
              <tr>
                <th>Sr.no</th>
                <th>Name</th>
                <th>Email</th>
                <th>Address</th>
                <th>Salary</th>
                <th>Contact Number</th>
                <th>CNIC Image</th>
                <th>Image</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {employee.map((emp, index) => (
                <tr key={emp.id}>
                  <td>{index + 1}</td>
                  <td>{emp.name}</td>
                  <td>{emp.email}</td>
                  <td>{emp.address}</td>
                  <td>{emp.salary}</td>
                  <td>{emp.contact_number}</td>

                  {/* Render CNIC Image */}
                  <td>
                    <LazyLoad height={200} offset={100} once>
                      <img
                        src={emp.cnic_image}
                        alt="Cnic Image"
                        style={{ width: '100px', height: '100px' }}
                      />
                    </LazyLoad>
                  </td>

                  {/* Render Employee Image */}
                  <td>
                    <LazyLoad height={200} offset={100} once>
                      <img
                        src={emp.image}
                        alt="Employee Image"
                        style={{ width: '100px', height: '100px' }}
                      />
                    </LazyLoad>
                  </td>

                  <td>
                    <Link to={`/dashboard/edit_employee/${emp.id}`} className="btn btn-warning btn-sm">
                      Edit
                    </Link>

                    <button
                      className="btn btn-danger btn-sm ms-5"
                      onClick={() => handleDelete(emp.id)} // Pass emp.id here
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No employees found.</p>
        )}
      </div>
    </div>
  );
};

export default Employee;
