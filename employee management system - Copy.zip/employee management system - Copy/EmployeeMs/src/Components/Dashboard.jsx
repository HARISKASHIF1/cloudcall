import React from 'react';
import 'bootstrap-icons/font/bootstrap-icons.css';
import { Link, Outlet, useNavigate } from 'react-router-dom'; 
import axios from 'axios';

const Dashboard = () => {
  const navigate = useNavigate();

  // Set credentials with axios globally to send cookies with requests
  axios.defaults.withCredentials = true;

  // Logout function
  const handleLogout = async () => {
    try {
      // Make the logout request
      const response = await axios.get('http://localhost:3006/api/admin/logout');
      
      if (response.data.Status) {
        // Clear local storage or any relevant data after logout
        localStorage.removeItem("valid");

        // Redirect to the login page after logout
        navigate('/adminLogin');
      } else {
        // Alert if logout fails
        alert('Logout failed. Please try again.');
      }
    } catch (error) {
      console.error('Logout error:', error);
      alert('An error occurred while logging out. Please try again.');
    }
  };

  return (
    <div className="container-fluid">
      <div className="row flex-nowrap">
        {/* Sidebar */}
        <div className="col-auto col-md-3 col-lg-2 px-0 bg-dark rounded-end shadow-lg" id="sidebar">
          <div className="d-flex flex-column align-items-center align-items-sm-start px-3 pt-4 text-white min-vh-100">
            <a href="/" className="d-flex align-items-center pb-3 mb-md-3 mt-md-3 text-white text-decoration-none">
              <span className="fs-4 fw-bold d-none d-sm-inline">Admin Dashboard</span>
            </a>

            <ul className="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start w-100" id="menu">
              <li className="w-100">
                <Link to="/dashboard" className="nav-link text-white px-0 py-2 align-middle w-100">
                  <i className="fs-4 bi-house-door"></i>
                  <span className="ms-2 d-none d-sm-inline">Dashboard</span>
                </Link>
              </li>
              <li className="w-100">
                <Link to="/dashboard/employee" className="nav-link text-white px-0 py-2 align-middle w-100">
                  <i className="fs-4 bi-person-lines-fill"></i>
                  <span className="ms-2 d-none d-sm-inline">Manage Employees</span>
                </Link>
              </li>
              <li className="w-100">
                <Link to="/dashboard/department" className="nav-link text-white px-0 py-2 align-middle w-100">
                  <i className="fs-4 bi-building"></i>
                  <span className="ms-2 d-none d-sm-inline">Department</span>
                </Link>
              </li>
              <li className="w-100">
                <Link to="/dashboard/attendance" className="nav-link text-white px-0 py-2 align-middle w-100">
                  <i className="fs-4 bi-calendar-check"></i>
                  <span className="ms-2 d-none d-sm-inline">Attendance</span>
                </Link>
              </li>
              <li className="w-100" onClick={handleLogout}>
                <Link className="nav-link px-0 align-middle text-white">
                  <i className="fs-4 bi-power ms-2"></i>
                  <span className="ms-2 d-none d-sm-inline">Logout</span>
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Main Content */}
        <div className="col px-4 py-3" id="main-content">
          <div className="centered-heading mb-3">
            <h4 className="heading fw-bold text-dark">Employee Management System</h4>
          </div>

          {/* Outlet for nested routes */}
          <div className="content-wrapper">
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
