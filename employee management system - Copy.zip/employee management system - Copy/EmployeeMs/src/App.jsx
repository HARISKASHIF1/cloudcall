import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './Components/Login';
import Dashboard from './Components/Dashboard';
import Home from './Components/Home';
import Department from './Components/Department';
import Attendance from './Components/Attendance';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'; // Import Navigate
import Employee from './Components/Employee';
import Adddepartment from './Components/Adddepartment';
import Addemployee from './Components/Addemployee';
import Editemployee from './Components/Editemployee';
import Employeelogin from './Components/Employeelogin';
import Employeedashboard from './Components/Employeedashboard';

function App() {
  const handleLoginSuccess = (employeeData) => {
    console.log('Employee logged in:', employeeData);
    // You can save the employee data to state or context here
  };

  return (
    <BrowserRouter>
      <Routes>
        {/* Route for admin login */}
        <Route path='/adminLogin' element={<Login />} />

        {/* Parent route for dashboard */}
        <Route path='/dashboard' element={<Dashboard />}>
          <Route path='' element={<Home />} />
          <Route path='employee' element={<Employee />} />
          <Route path='department' element={<Department />} />
          <Route path='attendance' element={<Attendance />} />
          <Route path='add-department' element={<Adddepartment />} />
          <Route path='add-employee' element={<Addemployee />} />
          <Route path='/dashboard/edit_employee/:id' element={<Editemployee />} />
        </Route>

        {/* Pass handleLoginSuccess as onLogin prop */}
        <Route path='/employeelogin' element={<Employeelogin onLogin={handleLoginSuccess} />} />
        <Route path='/employeedashboard' element={<Employeedashboard />} />

        {/* Redirect unknown paths to adminLogin */}
        <Route path="*" element={<Navigate to="/adminLogin" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
